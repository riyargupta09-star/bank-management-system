package com.bank;

public class SavingsAccount extends Account {
    private double interestRate;

    public SavingsAccount(String accountNumber, Customer owner, double balance, double interestRate) {
        super(accountNumber, owner, balance);
        this.interestRate = interestRate;
    }

    public void applyInterest() {
        synchronized(this) {
            balance += balance * interestRate;
        }
    }

    @Override
    public String getType() {
        return "Savings";
    }
}
