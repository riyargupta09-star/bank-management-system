package com.bank;

import java.util.*;

public class BankSystem {
    private static Bank bank = new Bank();
    private static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        seedSampleData();
        System.out.println("Welcome to Simple Bank Management System");
        boolean running = true;
        while (running) {
            printMenu();
            String choice = sc.nextLine().trim();
            switch (choice) {
                case "1": createAccount(); break;
                case "2": listAccounts(); break;
                case "3": deposit(); break;
                case "4": withdraw(); break;
                case "5": transfer(); break;
                case "6": simulateConcurrent(); break;
                case "0": running = false; break;
                default: System.out.println("Invalid choice"); break;
            }
        }
        System.out.println("Goodbye!");
    }

    private static void printMenu() {
        System.out.println("\nChoose: 1-Create 2-List 3-Deposit 4-Withdraw 5-Transfer 6-SimulateConcurrent 0-Exit");
        System.out.print("> ");
    }

    private static void seedSampleData() {
        if (bank.listAccounts().size() > 0) return;
        Customer c1 = new Customer("C001","Alice");
        Customer c2 = new Customer("C002","Bob");
        Account a1 = new SavingsAccount("A1001", c1, 10000, 0.02);
        Account a2 = new CurrentAccount("A1002", c2, 5000, 2000);
        bank.addAccount(a1);
        bank.addAccount(a2);
    }

    private static void createAccount() {
        System.out.print("Enter account number: ");
        String acc = sc.nextLine().trim();
        System.out.print("Owner name: ");
        String name = sc.nextLine().trim();
        System.out.print("Type (S for Savings / C for Current): ");
        String t = sc.nextLine().trim();
        System.out.print("Initial balance: ");
        double bal = Double.parseDouble(sc.nextLine().trim());
        Customer c = new Customer("C-" + acc, name);
        Account account;
        if (t.equalsIgnoreCase("S")) account = new SavingsAccount(acc, c, bal, 0.02);
        else account = new CurrentAccount(acc, c, bal, 1000);
        bank.addAccount(account);
        System.out.println("Account created: " + acc);
    }

    private static void listAccounts() {
        System.out.println("Accounts:");
        for (Account a : bank.listAccounts()) {
            System.out.println(a.getAccountNumber() + " | " + a.getOwner().getName() + " | " + a.getType() + " | " + a.getBalance());
        }
    }

    private static void deposit() {
        System.out.print("Account number: ");
        String acc = sc.nextLine().trim();
        System.out.print("Amount: ");
        double amt = Double.parseDouble(sc.nextLine().trim());
        boolean ok = bank.deposit(acc, amt);
        System.out.println(ok ? "Deposit successful" : "Deposit failed");
    }

    private static void withdraw() {
        System.out.print("Account number: ");
        String acc = sc.nextLine().trim();
        System.out.print("Amount: ");
        double amt = Double.parseDouble(sc.nextLine().trim());
        boolean ok = bank.withdraw(acc, amt);
        System.out.println(ok ? "Withdraw successful" : "Withdraw failed or insufficient funds");
    }

    private static void transfer() {
        System.out.print("From account: ");
        String f = sc.nextLine().trim();
        System.out.print("To account: ");
        String t = sc.nextLine().trim();
        System.out.print("Amount: ");
        double amt = Double.parseDouble(sc.nextLine().trim());
        boolean ok = bank.transfer(f, t, amt);
        System.out.println(ok ? "Transfer successful" : "Transfer failed");
    }

    private static void simulateConcurrent() {
        System.out.println("Starting concurrent simulation between two ATMs on same account.");
        System.out.print("Enter account number to stress: ");
        String acc = sc.nextLine().trim();
        System.out.print("Number of ATM threads: ");
        int n = Integer.parseInt(sc.nextLine().trim());
        System.out.print("Operations per thread: ");
        int ops = Integer.parseInt(sc.nextLine().trim());
        Thread[] threads = new Thread[n];
        for (int i = 0; i < n; i++) {
            threads[i] = new Thread(new ATMThread(bank, acc, ops), "ATM-" + (i+1));
            threads[i].start();
        }
        for (int i = 0; i < n; i++) {
            try { threads[i].join(); } catch (InterruptedException ignored) {}
        }
        System.out.println("Simulation complete. Current balance: " + (bank.getAccount(acc) != null ? bank.getAccount(acc).getBalance() : "N/A"));
    }
}
