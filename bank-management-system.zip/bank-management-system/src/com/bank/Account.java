package com.bank;

import java.io.Serializable;

public abstract class Account implements Serializable {
    protected String accountNumber;
    protected Customer owner;
    protected double balance;

    public Account(String accountNumber, Customer owner, double balance) {
        this.accountNumber = accountNumber;
        this.owner = owner;
        this.balance = balance;
    }

    public String getAccountNumber() { return accountNumber; }
    public Customer getOwner() { return owner; }
    public synchronized double getBalance() { return balance; }

    public synchronized boolean deposit(double amount) {
        if (amount <= 0) return false;
        balance += amount;
        return true;
    }

    // withdraw implemented by subclasses (overridable)
    public synchronized boolean withdraw(double amount) {
        if (amount <= 0) return false;
        if (balance >= amount) {
            balance -= amount;
            return true;
        }
        return false;
    }

    public abstract String getType();

    @Override
    public String toString() {
        return String.format("%s|%s|%s|%.2f", getAccountNumber(), owner.getName(), getType(), getBalance());
    }
}
