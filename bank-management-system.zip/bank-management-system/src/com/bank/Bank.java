package com.bank;

import java.util.*;
import java.io.*;

public class Bank {
    private Map<String, Account> accounts = new HashMap<>();
    private List<String> transactions = new ArrayList<>();
    private final File storageDir = new File("data");
    private final File accountsFile = new File(storageDir, "accounts.txt");

    public Bank() {
        if (!storageDir.exists()) storageDir.mkdirs();
        loadAccounts();
    }

    public synchronized void addAccount(Account acc) {
        accounts.put(acc.getAccountNumber(), acc);
        transactions.add("Account created: " + acc.getAccountNumber());
        saveAccounts();
    }

    public Account getAccount(String accNum) {
        return accounts.get(accNum);
    }

    public synchronized boolean transfer(String fromAcc, String toAcc, double amount) {
        Account a1 = accounts.get(fromAcc);
        Account a2 = accounts.get(toAcc);
        if (a1 == null || a2 == null) return false;
        // lock ordering to avoid deadlock: order by account number
        Account first = a1.getAccountNumber().compareTo(a2.getAccountNumber()) < 0 ? a1 : a2;
        Account second = first == a1 ? a2 : a1;
        synchronized (first) {
            synchronized (second) {
                if (a1.withdraw(amount)) {
                    a2.deposit(amount);
                    transactions.add(String.format("Transfer %.2f from %s to %s", amount, fromAcc, toAcc));
                    saveAccounts();
                    return true;
                } else {
                    return false;
                }
            }
        }
    }

    public synchronized boolean deposit(String accNum, double amount) {
        Account a = accounts.get(accNum);
        if (a == null) return false;
        boolean ok = a.deposit(amount);
        if (ok) {
            transactions.add(String.format("Deposit %.2f to %s", amount, accNum));
            saveAccounts();
        }
        return ok;
    }

    public synchronized boolean withdraw(String accNum, double amount) {
        Account a = accounts.get(accNum);
        if (a == null) return false;
        boolean ok = a.withdraw(amount);
        if (ok) {
            transactions.add(String.format("Withdraw %.2f from %s", amount, accNum));
            saveAccounts();
        }
        return ok;
    }

    public List<Account> listAccounts() {
        return new ArrayList<>(accounts.values());
    }

    private void loadAccounts() {
        if (!accountsFile.exists()) return;
        try (BufferedReader br = new BufferedReader(new FileReader(accountsFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                // format: accNum|name|type|balance
                String[] parts = line.split("\\|");
                if (parts.length < 4) continue;
                String accNum = parts[0];
                String name = parts[1];
                String type = parts[2];
                double bal = Double.parseDouble(parts[3]);
                Customer c = new Customer("C-" + accNum, name);
                Account acc;
                if (type.equalsIgnoreCase("Savings")) acc = new SavingsAccount(accNum, c, bal, 0.02);
                else acc = new CurrentAccount(accNum, c, bal, 5000);
                accounts.put(accNum, acc);
            }
        } catch (Exception e) {
            System.err.println("Failed to load accounts: " + e.getMessage());
        }
    }

    private void saveAccounts() {
        try (PrintWriter pw = new PrintWriter(new FileWriter(accountsFile))) {
            for (Account a : accounts.values()) {
                pw.println(a.toString());
            }
        } catch (Exception e) {
            System.err.println("Failed to save accounts: " + e.getMessage());
        }
    }
}
