package com.bank;

import java.util.Random;

// Simulates a bank ATM doing random deposits/withdrawals concurrently
public class ATMThread implements Runnable {
    private Bank bank;
    private String accountNumber;
    private Random rnd = new Random();
    private int operations;

    public ATMThread(Bank bank, String accountNumber, int operations) {
        this.bank = bank;
        this.accountNumber = accountNumber;
        this.operations = operations;
    }

    @Override
    public void run() {
        for (int i = 0; i < operations; i++) {
            double amount = (rnd.nextInt(10) + 1) * 100; // 100..1000
            if (rnd.nextBoolean()) {
                bank.deposit(accountNumber, amount);
                System.out.println(Thread.currentThread().getName() + " deposited " + amount + " to " + accountNumber);
            } else {
                boolean ok = bank.withdraw(accountNumber, amount);
                System.out.println(Thread.currentThread().getName() + " withdraw " + amount + " from " + accountNumber + " => " + ok);
            }
            try { Thread.sleep(rnd.nextInt(200)); } catch (InterruptedException ignored) {}
        }
    }
}
