# Bank Management System (Java)

Simple console-based Bank Management System demonstrating:
- Object-oriented design (inheritance, encapsulation)
- Collections Framework (HashMap, ArrayList)
- Multithreading (simulated concurrent transactions with Runnable)
- Synchronization for thread-safety
- File-based persistence (accounts stored in `data/accounts.txt`)

## Project Structure
```
bank-management-system/
├─ src/com/bank/
│  ├─ Account.java
│  ├─ SavingsAccount.java
│  ├─ CurrentAccount.java
│  ├─ Customer.java
│  ├─ Bank.java
│  ├─ ATMThread.java
│  └─ BankSystem.java
├─ data/
│  └─ accounts.txt   (created at runtime)
└─ README.md
```

## How to compile & run (from project root)
1. Open terminal in this folder.
2. Compile:
   ```
   javac -d out src/com/bank/*.java
   ```
3. Run:
   ```
   java -cp out com.bank.BankSystem
   ```

## Notes
- This is a simple educational example. Do not use for production.
- The program creates a `data/accounts.txt` file for simple persistence.
